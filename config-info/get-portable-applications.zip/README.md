## 1.把dist下所有内容,复制到当前文件夹下

## 2. **确保项目结构**
首先，确保项目文件结构如下：
```
my-electron-app/
├── assets/
├── index.html
├── main.js
├── package.json
```

## 3. **更新 `index.html`**

确保 HTML 文件正确引用本地资源：资源引用前加/

## 4. **安装 Electron**

确保已安装 Electron：

```bash
npm install electron --save-dev
```

## 5. **打包应用**
使用 `electron-packager` 来打包应用：

### 1. 安装 `electron-packager`：

   ```bash
   npm install electron-packager --save-dev
   ```

### 2. 运行打包命令：

   ```bash
   npx electron-packager . SchoolBell --platform=win32 --arch=x64 --out=dist --overwrite
   ```

这个命令将为您的应用生成一个 Windows 平台的 `.exe` 文件，并将其保存在 `dist/` 目录下。

您可以将 `dist/` 文件夹中的生成文件打包并分享给用户。
